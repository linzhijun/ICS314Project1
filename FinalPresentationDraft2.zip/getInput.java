import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *Authors: Team Tres
 *Demo for iCalendar;
 *April 27, 2016
 */
public class getInput {

	
	  /* Function getYear
	  * Parameter: n/a
	  * Description: Asks for two digit input (assumes it takes place in 20xx)
	  * 			then returns it as 20xx.
	  * Returns: (String) : year
	  */
	  private static String getYear() {
		  
		  Scanner scan = new Scanner(System.in);
		  int year = 16;
		  int running = 1;
		  String output = "16";
		  
		  while (running == 1) {
			  System.out.print("Input year(2 digit): 20");
			  
			  try {
				  year = scan.nextInt();
				  //scan.nextLine(); 
				  
				  if(year < 0 || year > 99) {
					  System.out.println("year invalid");
				  }
				  else {
					  output = Integer.toString(year);
					  if(output.length() == 1) {
						  output = "0" + output; //if 9, outputs 2009
					  }
					  output = "20" + output;
					  running = 0;
				  }
				  
			  }
			  catch (InputMismatchException a) {
				  System.out.println("Please enter an integer");
				  scan.next();
			  }
			  
		  }
		  
		  return(output);
	  }
	  
	  
	  /* Function getMonth
	   * Parameter: n/a
	   * Description: asks for two digit input to get month
	   * Returns: (String) : month
	   */
	  private static String getMonth() {
		  
		  Scanner scan = new Scanner(System.in);
		  int month = 0;
		  int running = 1;
		  String output = "";
		  
		  while (running == 1) {
			  System.out.print("Input month(2 digit):");
			  
			  try {
				  month = scan.nextInt();
				  //scan.nextLine(); 
				  
				  if(month < 0 || month > 12) {
					  System.out.println("month invalid");
				  }
				  else {
					  output = Integer.toString(month);
					  if(output.length() == 1) {
						  output = "0" + output; //if 9, assumes 09 or September
					  }
					  running = 0;
				  }
				  
			  }
			  catch (InputMismatchException a) {
				  System.out.println("Please enter an integer");
				  scan.next();
			  }
			  
		  }
		  
		  return(output);
	  }
	  
	  
	  /* Function getDay
	   * Parameter: n/a
	   * Description: Asks for two digit input to get day
	   * Returns: (String) : day
	   */
	  private static String getDay() {
		  
		  Scanner scan = new Scanner(System.in);
		  int day = 0;
		  int running = 1;
		  String output = "";
		  
		  while (running == 1) {
			  System.out.print("Input day(2 digit):");
			  
			  try {
				  day = scan.nextInt();
				  //scan.nextLine(); 
				  
				  if(day < 0 || day > 31) {
					  System.out.println("day invalid");
				  }
				  else {
					  output = Integer.toString(day);
					  if(output.length() == 1) {
						  output = "0" + output; //if input is 9, returns 09
					  }
					  running = 0;
				  }
				  
			  }
			  catch (InputMismatchException a) {
				  System.out.println("Please enter an integer");
				  scan.next();
			  }
			  
		  }
		  
		  return(output);
	  }
	  
	  /* Function getHour
	   * Parameter: n/a
	   * Description: Asks for four digit input to get hour, does not concern with the last two digits
	   * 			as they are seconds (very few people plan by the second)
	   * Returns: (String) : hour
	   */
	  private static String getHour() {
		  
		  Scanner scan = new Scanner(System.in);
		  int hour = 0;
		  int running = 1;
		  String output = "";
		  
		  while (running == 1) {
			  System.out.print("Input hour(4 digit):");
			  
			  try {
				  hour = scan.nextInt();
				  //scan.nextLine(); 
				  
				  if(hour < 0 || hour > 2400) {
					  System.out.println("hour invalid");
				  }
				  else {
					  output = Integer.toString(hour);
					  
					  if(output.length() == 1) {
						  output = "0" + output + "00";
					  }
					  else if (output.length() == 2) {
						  if (hour < 24) {
							  output = output + "00";
						  }
						  else {
							  output = "0" + output + "0";
						  }
					  }
					  else if (output.length() == 3) {
						  output = "0" + output;
					  }
					  running = 0;
				  }
				  
			  }
			  catch (InputMismatchException a) {
				  System.out.println("Please enter an integer");
				  scan.next();
			  }
			  
		  }
		  
		  return(output);
	  }
		
		
	  /* Function getTime
	   * Parameter: n/a
	   * Description: Construct a time string for event files.
	   * Returns: (String) : time sring
	   */
	  public static String getTime() {
		  String output;
		  
		  output = getYear();
		  output = output + getMonth();
		  output = output + getDay();
		  output = output + "T" + getHour() + "00Z";

		  return(output);
	  }
	  
	  /* Function getClass
	  Asks user for input, depending on the input outputs
	  PUBLIC, PRIVATE, CONFIDENTIAL, IANA-TOKEN, or x-name
	  If the input is non an integer, output is automatically set to PUBLIC
	  */
	  public static String getClassification() {
	  		Scanner inText = new Scanner(System.in);
	  		int input = 0;
	  		int loop = 1; //control variable for the loop, if 1 continues loop. if 0 ends loop
	  		String output = "PUBLIC";
	  	 
	  		System.out.println("Press 1 for PUBLIC, press 2 for PRIVATE, press 3 for CONFIDENTIAL, Press 4 for iana-token, Press 5 for x-name");
	  		while(loop == 1) {
	  	 
	  			try {
	  				input = inText.nextInt();
	  			} catch (InputMismatchException e) {
	  				System.out.println("Input is not an integer");
	  				break;
	  			}
	  	     
	  			if(input == 1) {
	  				output = "PUBLIC";
	  				loop = 0;
	  			}
	  			else if(input == 2) {
	  				output = "PRIVATE";
	  				loop = 0;
	  			}
	  			else if(input == 3) {
	  				output = "CONFIDENTIAL";
	  				loop = 0;
	  			}
	  			else if(input == 4) {
	  				output = "iana-token";
	  				loop = 0;
	  			}
	  			else if(input == 5) {
	  				output = "x-name";
	  				loop = 0;
	  			}
	  		}
	  	 
	  	 //System.out.println("");
	  	 return(output);
	  }
	  
	  /* Function getGeopos
	   * Parameter: n/a
	   * Description: Asks for latitude and longitude to get the geopos
	   * Returns: (String) : geographical position
	   */
	  public static String getGeopos() {
	  		Scanner scan = new Scanner(System.in);
	  		String output = "";
	  		int running = 1;
	  		double lat = 0;
	  		double lon = 0;
	  		
			  while (running == 1) {
				  
				  try {
					  System.out.print("Input latitude:");
					  lat = scan.nextDouble();
					  //scan.nextLine(); 
					  
					  if(lat < -90 || lat > 90) {
						  System.out.println("latitude invalid, must be between -90 and 90");
					  }
					  else {
						  lat = Math.round(lat * 1000000.0) / 1000000.0;
						  running = 0;
					  }
					  
				  }
				  catch (InputMismatchException a) {
					  System.out.println("Please enter a double");
					  scan.next();
				  }
				  
			  }
			  
			  running = 1;
			  
			  while (running == 1) {
				  
				  try {
					  System.out.print("Input longitude:");
					  lon = scan.nextDouble();
					  //scan.nextLine(); 
					  
					  if(lon < -180 || lon > 180) {
						  System.out.println("longitude invalid, must be between -180 and 180");
					  }
					  else {
						  lon = Math.round(lon * 1000000.0) / 1000000.0;
						  running = 0;
					  }
					  
				  }
				  catch (InputMismatchException a) {
					  System.out.println("Please enter a double");
					  scan.next();
				  }
				  
			  }
			  
	  		output = lat + ";" + lon;
			  
	  		return(output);
	  }
	  
}
