import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.Calendar;
import java.util.TimeZone;

/**
 *Authors: Team Tres
 *Demo for iCalendar;
 *April 23, 2016
 */
public class Driver {
	
	//list of events to be written to and read from
	private static ArrayList<Event> eventAL = new ArrayList<Event>();
	
	
  /* Function newEvent
  * Parameter: n/a
  * Description: Takes various user input to create a new event
  * Returns: (Event) : A new event
  */
  private static Event newEvent(){
	  
	  Scanner inText = new Scanner(System.in);
	  String loc;
	  String summ;
	  String desc;
	  String geopos;
	  String start;
	  String end;
	  String comment;
	  String cls;
	  String tzid;
	  Event newEvent = new Event();
	  
	  System.out.println("Please enter location: ");
	  loc = inText.nextLine();
	    
	  System.out.println("Please enter summary: ");
	  summ = inText.nextLine();
	    
	  System.out.println("Please enter description: ");
	  desc = inText.nextLine();
	  
	  System.out.println("Please enter comment: ");
	  comment = inText.nextLine();
	    
	  //System.out.println("Please enter geographical position (format: " + "37.386013;" + "-122.082932): ");
	  //geopos = inText.nextLine();
	  
	  geopos = getInput.getGeopos();
	    
	  //System.out.println("Please enter start time (format: 20160225T153000Z): ");
	  System.out.println("Please enter information for start time");
	  start = getInput.getTime();
	    
	  //System.out.println("Please enter end time (format: 20160225T163000Z): ");
	  System.out.println("Please enter information for end time");
	  end = getInput.getTime();
	  
	  cls = getInput.getClassification();
	  
	  Calendar now = Calendar.getInstance();
	    
	  //get current TimeZone using getTimeZone method of Calendar class
	  //also assumes that the Timezone will be equal to the computer's timezone
	  TimeZone timeZone = now.getTimeZone();
	    
	  tzid = timeZone.getDisplayName();

	  
  	  newEvent.dtstart = start;
  	  newEvent.dtend = end;
  	  newEvent.desc = desc;
  	  newEvent.location = loc;
  	  newEvent.summary = summ;
  	  newEvent.comment = comment;
  	  newEvent.geo = geopos;
  	  newEvent.cls = cls;
  	  newEvent.tzid = tzid;
  	  
  	  System.out.println("New event created");
  	  
  	  return(newEvent);
  }
  
  
  /* Function read
  * Parameter: (String) filename : file to be read
  * Description: reads from a specified file to get one or more events
  * Returns: void
  */
  private static void read(String filename){
	  ArrayList<Event> newEvents = Reader.getInput(filename);
	  System.out.println("Read " + newEvents.size() + " events");
	  eventAL.addAll(newEvents);
  }
  
  
  /* Function write
  * Parameter: n/a
  * Description: Takes a user input for the output file, then writes down
  * 			 events from eventAL
  * Returns: void
  */
  private static void write(){
	  
	  Scanner scanw = new Scanner(System.in);
	  String input = "";
	  
	  eventAL = Reader.InsertionSort(eventAL);
	  eventAL = Reader.getGCD(eventAL);
	  
	  System.out.print("Enter a filename for output: ");
	  input = scanw.nextLine();
	  System.out.println();
	  
	  Jog.setLogger(new FileLogger(input));
	  
	    Jog.enableLevel(Level.BEGIN);
	    Jog.enableLevel(Level.CALSCALE);
	    Jog.enableLevel(Level.PRODID);
	    Jog.enableLevel(Level.DESCRIPTION);
	    Jog.enableLevel(Level.VERSION);
	    Jog.enableLevel(Level.DESCRIPTION);
	    Jog.enableLevel(Level.END);
	    Jog.enableLevel(Level.DTSTART);
	    Jog.enableLevel(Level.DTEND);
	    Jog.enableLevel(Level.LOCATION);
	    Jog.enableLevel(Level.COMMENT);
	    Jog.enableLevel(Level.SUMMARY);
	    Jog.enableLevel(Level.GEO);
	    Jog.enableLevel(Level.CLASS);
	    Jog.enableLevel(Level.TZID);
	  
	    
	    Jog.begin("VCALENDAR");
	    Jog.prodid("-//Kerwin Yadao//ics314 1.0//EN");
	    Jog.version("2.0");
	    Jog.calscale("GREGORIAN");
	    
	  for(int x = 0; x < eventAL.size();x++) {
		  
		  
		    Jog.begin("VEVENT");
		    Jog.tzid(eventAL.get(x).tzid);
		    Jog.dtstart(eventAL.get(x).dtstart);
		    Jog.dtend(eventAL.get(x).dtend);
		    Jog.description(eventAL.get(x).desc);
		    Jog.location(eventAL.get(x).location);
		    Jog.summary(eventAL.get(x).summary);
		    Jog.comment(eventAL.get(x).comment);
		    Jog.geo(eventAL.get(x).geo);
		    Jog.Class(eventAL.get(x).cls);
		    Jog.end("VEVENT");		  
	  }
	    Jog.end("VCALENDAR");
	    
	    System.out.println("file written");
  }
	
	
  /* Function main
  * Parameter: String[] args
  * Description: The driver function for the program, takes user input
  * 			 and based on their input, does variety of things.
  * Returns: void
  */
  public static void main(String[] args) {    
	  
	  int run = 1;
	  Scanner scan = new Scanner(System.in); 
	  String input = "";
	  ArrayList<String> inList = new ArrayList<String>();
	  
	  while(run == 1) {
		  
		  System.out.println("Commands: show-events, new-event, read, write, quit, help");
		  System.out.print("enter command:");
		  input = scan.nextLine();
		  
		  System.out.println();
		  
		  if (input.equals("quit") ) {
			  run = 0; //exits from loop
		  }
		  else if(input.equals("help")) {
			  System.out.println("The program keeps a list of events");
			  System.out.println("showEvents prints out a list of events");
			  System.out.println("newEvent creates a new event and adds to the list");
			  System.out.println("read reads from an existing ics file then adds to the list");
			  System.out.println("write write to an existing or a new ics file");
			  System.out.println("The program automatically sorts the events based on time and calculates GCD");
			  System.out.println("NOTE: The program assumes that all event occurs in the same day");
		  }
		  else if(input.equals("show-events")) {
		      for(int x = 0; x < eventAL.size();x++) {
		    	  System.out.println();
				  System.out.println("Event " + (x + 1));
				  System.out.println("Timezone Identifier is: " + eventAL.get(x).tzid);
				  System.out.println("start time is: " + eventAL.get(x).dtstart);
				  System.out.println("end time is: " + eventAL.get(x).dtend);
				  System.out.println("desc is: " + eventAL.get(x).desc);
				  System.out.println("location is: " + eventAL.get(x).location);
				  System.out.println("Summary is: " + eventAL.get(x).summary);
				  System.out.println("comment is: " + eventAL.get(x).comment);
				  System.out.println("geopos is: " + eventAL.get(x).geo);
				  System.out.println("classification is: " + eventAL.get(x).cls);
			  }
		      
		      if(eventAL.size() == 0) {
		    	  System.out.println("no events");
		      }
		  }
		  else if(input.equals("new-event")) {
			  //System.out.println("create new:");
			  eventAL.add(newEvent());
		  }
		  else if(input.equals("read")) {
			  System.out.print("enter filename:");
			  input = scan.nextLine();
			  read(input);
			  //inList.add(input);
		  }
		  else if(input.equals("write")) {
			  //write(inList);
			  write();
		  }
		  else {
			  System.out.println("unknown input");
		  }
		  System.out.println("-------------------------------------------------");
	  }
	  
	  
	  System.out.println("end of program");
	  
  }

}
