
/*
This is the event class, it should hold all the necessary fields
*/
public class Event {


	//public String fileName;
    public String dtstart;
    public String dtend;
    public String desc;
    public String location;
    public String summary;
    public String comment;
    public String geo;
    public String cls;
    public String tzid;
	
    
	public Event() {
	    dtstart = null;
	    dtend = null;
	    desc = null;
	    location = null;
	    summary = null;
	    comment = null;
	    geo = null;
	    cls = null;
	    tzid = null;
	}
}