import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.ArrayList;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

/**
 *Authors: Team Tres
 *Contains methods to read from .ics files and to
 *calculate GCD between events
 *February 25, 2016
 */
public class Reader {

//scaner to be used on the functions
public static Scanner inText = new Scanner(System.in);


	/* Function getInput
	 * Parameter: (String) filename : filename to be opened
	 * Description: takes a filename, opens a specific file then
	 * 				extracts information to conscrupt an array of events
	 * Returns: (ArratList<Event>) : ArrayList of Events with information extacted from file
	*/
	public static ArrayList<Event> getInput(String filename) {
		//array of events to be returned
		ArrayList<Event> newAL = new ArrayList<Event>();

		  Event newEvent = null;
		  
		  String line = null;
		  String line2 = null;
		  String dtstart = "";
		  String dtend = "";
		  String desc = "";
		  String location = "";
		  String summary = "";
		  String comment = "";
		  String geo = "";
		  String cls = "";
		  String tzid = "";
		  
		  	  //if file does not exist, gives error message
			  try {
			            FileReader fileReader = new FileReader(filename);
			            BufferedReader bufferedReader = new BufferedReader(fileReader);
	
			            while((line = bufferedReader.readLine()) != null) {
			                line2 = "";
			                
			                
	                        if(line.equals("BEGIN:VEVENT") ){
	                        	//System.out.println("Created new");
	                        	
	                        	newEvent = new Event();
	                        }
	                        else if(line.equals("END:VEVENT") ){
	                        	
	                        	//System.out.println("adding");
	                        	
	                        	newEvent.dtstart = dtstart;
	                        	newEvent.dtend = dtend;
	                        	newEvent.desc = desc;
	                        	newEvent.location = location;
	                        	newEvent.summary = summary;
	                        	newEvent.comment = comment;
	                        	newEvent.geo = geo;
	                        	newEvent.cls = cls;
	                        	newEvent.tzid = tzid;
	                        	
	                        	newAL.add(newEvent);
	                        	
	                  		    dtstart = "";
	                		    dtend = "";
	                		    desc = "";
	                		    location = "";
	                		    summary = "";
	                		    comment = "";
	                		    geo = "";
	                		    cls = "";
	                		    tzid = "";
	                        }
	                        else {
				                for (int x = 0; x < line.length();x++) {
		                      
				                    //System.out.println(line2);
		                            if(line2.equals("DTSTART:") ){
		                            	dtstart = dtstart + line.charAt(x);
		                            }
		                            else if(line2.equals("DTEND:") ){
		                            	dtend = dtend + line.charAt(x);
		                            }
		                            else if(line2.equals("DESCRIPTION:") ){
		                            	desc = desc + line.charAt(x);
		                            }
		                            else if(line2.equals("LOCATION:") ){
		                            	location = location + line.charAt(x);
		                            }
		                            else if(line2.equals("SUMMARY:") ){
		                            	summary = summary + line.charAt(x);
		                            }
		                            else if(line2.equals("COMMENT:") ){
		                            	comment = comment + line.charAt(x);
		                            }
		                            else if(line2.equals("GEO:") ){
		                            	geo = geo + line.charAt(x);
		                            }
		                            else if(line2.equals("CLASS:") ){
		                            	cls = cls + line.charAt(x);
		                            }
		                            else if(line2.equals("TZID:") ){
		                            	tzid = tzid + line.charAt(x);
		                            }
		                            else {
		                                line2 = line2 + line.charAt(x);
		                            }
		                      
				                }
				                
	                        }
			            }
			            bufferedReader.close();         
			  }  
			  catch(IOException ex) {
				  System.out.println("file not found");
			      //ex.printStackTrace();                 
			  }

		
		
		return(newAL);
	}

	/* Function InsertionSort
	 * Parameter: (ArrayList<Event>) input : AL to be sorted
	 * Description: Takes a list of arrays then sort them using insertion sort
	 * 				Sorts based on the start time (hour) of the event
	 * Returns: (ArratList<Event>) : Sorted out array list
	*/
	 public static ArrayList<Event> InsertionSort(ArrayList<Event> input){
         
	        Event temp;
	        for (int i = 1; i < input.size(); i++) {
	            for(int j = i ; j > 0 ; j--){
	            	//getDate(input.get(j).dtstart);
	                if( getDate(input.get(j).dtstart) < getDate(input.get(j-1).dtstart) ){
	                    temp = input.get(j);
	                    input.set(j, input.get(j-1));
	                    input.set(j-1, temp);
	                }
	            }
	        }
	        return input;
	 }
	
	/* Function getDate
	* Parameter: (String) datetime : a datetime string to be decoded
	* Description: takes a datetime string then gets the date
	* Returns: (int) : the date
	*/
	 public static int getDate(String datetime){
		 
		 int swt = 0;
		 String line = "";
		 //String line2 = "";
		 
		 for(int x = 0; x < datetime.length();x++) {

			 if(swt == 1) {
				 
				 if (datetime.charAt(x) != 'Z') {
					 line = line + datetime.charAt(x);
				 }
			 }
			 else if(datetime.charAt(x) == 'T') {
				 swt = 1;
			 }
		 }
		 int out = Integer.parseInt(line);
		 return(out);
	 }
	 
	/* Function getGeo
	* Parameter: (String) geopos : a geopos string to be decoded
	* Description: takes a geopos string then gets the latitude and the longitude
	* Returns: (double[]) : A list of doubles, position 0 holds the latitude
	* 						while position 1 holds longitude
	*/
	 public static double[] getGeo(String geopos){
		 
		 double geo[] = new double[2]; //position 0 is the latitude, 1 is longitude
		 String lat = "";
		 String lon = "";
		 int swt = 0;
		 
		 //System.out.println(geopos);
		 
		 if (geopos != "") {
			 for(int x = 0; x < geopos.length();x++) {
	
				 if (geopos.charAt(x) == ';') {
					 swt = 1;
				 }
			     else if(swt == 1) {
			    	  lat = lat + geopos.charAt(x);
				 }
				 else {
					 lon = lon + geopos.charAt(x);
				 }
			 }
			 
			 geo[0] = Double.parseDouble(lat);
			 geo[1] = Double.parseDouble(lon);
		 }
		 else {
			 System.out.println("geopos is null");
			 geo = null;
		 }
		 //int out = Integer.parseInt(line);
		 //System.out.println("Lat is:" + lat);
		 //System.out.println("Long is:" + lon);
		 
		 //System.out.println("geoPos is good");
		 
		 return(geo);
	 }
	 
		/* Function GreatCircleDistance
		* Parameter: (double) lat1 : latitude of first event
		* Parameter: (double) lon2 : longitude of first event
		* Parameter: (double) lat2 : latitude of second event
		* Parameter: (double) lon2 : longitude of second event
		* Description: takes the latitude and longitude of two events then calculate
		* 				the Great Circle Distance
		* Returns: (double) : the Great Cirle Distance between two events
		*/
		public static double GreatCircleDistance(double lat1, double lon1, double lat2, double lon2) {
				// same position
				if(lat1 == lat2 && lon1 == lon2) {
					return 0;
				}
				/* Earth Mean Radius */
				//final double earthRmile = 3953.0;
				final double earthRKm = 6371;
				double lat1R = Math.toRadians(lat1);
				double lat2R = Math.toRadians(lat2);
				double dLat = Math.toRadians(lat2 - lat1);
				double dLon = Math.toRadians(lon2 - lon1);
				double a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1R) * Math.cos(lat2R) * Math.sin(dLon/2) * Math.sin(dLon/2);
				double c = 2 * Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
				double dist = earthRKm * c;
				return dist;
				
				//check dist
		}

		
		/* Function getGCD
		* Parameter: (ArrayList<Event>) input : latitude of first event
		* Description: Takes a list of events, sort them based on start time then calculate
		* 				the great circle distance between each events.
		* 				The first and last event does not have GCD
		* Returns: (ArrayList<Event>) : A sorted list of events with GCD added on comment secton
		*/
		 public static ArrayList<Event> getGCD(ArrayList<Event> input){
			    //first position is the latitude, second position is the longitude
	         	double latlong1[] = new double[2];
	         	double latlong2[] = new double[2];
	         	double gcd = 0;
	         	double gcdmile = 0;
			 
		        for (int i = 0; i < (input.size() - 1); i++) {
		        	
		        	latlong1 = getGeo(input.get(i).geo);
		        	latlong2 = getGeo(input.get(i + 1).geo);
		        	
		        	//if the first geopos is empty/null, assumes geopos is 0;0
		         	if(latlong1 == null) {
		         		latlong1 = new double[2];
		         		latlong1[0] = 0;
		         		latlong1[1] = 0;
		         	}
		        	
		        	//if the next geopos is empty/null, assumes geopos same as the last one
		         	if(latlong2 == null) {
		         		latlong2 = new double[2];
		         		latlong2[0] = latlong1[0];
		         		latlong2[1] = latlong1[1];
		         	}
		        	
		        	gcd = GreatCircleDistance(latlong1[0], latlong1[1], latlong2[0], latlong2[1]);
		        	
		        	gcdmile = Math.round((gcd*0.621371) * 100.0) / 100.0;
		        	gcd = Math.round(gcd * 100.0) / 100.0;
		        	
		        	input.get(i).comment = "Great Circle Distance=" + gcd + "km/" + gcdmile + "mi" ;
		        	//input.get(i).comment = "Great Circle Distance=" + gcd + "km/" + (gcd * 0.621371) + "mi" ;
		        }
		        return input;
		 }






}