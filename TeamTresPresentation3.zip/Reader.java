import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.ArrayList;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

/**
 *Authors: Team Tres
 *First Team Deliverable
 *Demo for iCalendar;
 *February 25, 2016
 */
public class Reader {

public static Scanner inText = new Scanner(System.in);

	public static ArrayList<Event> getInput(ArrayList<String> al) {
		
		ArrayList<Event> newAL = new ArrayList<Event>();
		//Event newEvent = new Event();
		
		
		  Event newEvent = null;
		
		  //String LogFile = "test.ics";
		  
		  String line = null;
		  String line2 = null;
		  String dtstart = "";
		  String dtend = "";
		  String desc = "";
		  String location = "";
		  String summary = "";
		  String comment = "";
		  String geo = "";
		  
		  for(int i = 0; i < al.size();i++) {
			  
			  String LogFile = al.get(i);
		  
			  try {
			            FileReader fileReader = new FileReader(LogFile);
			            
			            BufferedReader bufferedReader = new BufferedReader(fileReader);
	
			            while((line = bufferedReader.readLine()) != null) {
			            	//System.out.println("lol");
			                //System.out.println(line);
			                line2 = "";
			                
			                
	                        if(line.equals("BEGIN:VEVENT") ){
	                        	//System.out.println("Created new");
	                        	
	                        	newEvent = new Event();
	                        }
	                        else if(line.equals("END:VEVENT") ){
	                        	
	                        	//System.out.println("adding");
	                        	
	                        	newEvent.dtstart = dtstart;
	                        	newEvent.dtend = dtend;
	                        	newEvent.desc = desc;
	                        	newEvent.location = location;
	                        	newEvent.summary = summary;
	                        	newEvent.comment = comment;
	                        	newEvent.geo = geo;
	                        	
	                        	newAL.add(newEvent);
	                        	
	                  		    dtstart = "";
	                		    dtend = "";
	                		    desc = "";
	                		    location = "";
	                		    summary = "";
	                		    comment = "";
	                		    geo = "";
	                        }
	                        else {
				                for (int x = 0; x < line.length();x++) {
		                      
				                    //System.out.println(line2);
		                            if(line2.equals("DTSTART:") ){
		                            	dtstart = dtstart + line.charAt(x);
		                            }
		                            else if(line2.equals("DTEND:") ){
		                            	dtend = dtend + line.charAt(x);
		                            }
		                            else if(line2.equals("DESCRIPTION:") ){
		                            	desc = desc + line.charAt(x);
		                            }
		                            else if(line2.equals("LOCATION:") ){
		                            	location = location + line.charAt(x);
		                            }
		                            else if(line2.equals("SUMMARY:") ){
		                            	summary = summary + line.charAt(x);
		                            }
		                            else if(line2.equals("COMMENT:") ){
		                            	comment = comment + line.charAt(x);
		                            }
		                            else if(line2.equals("GEO:") ){
		                            	geo = geo + line.charAt(x);
		                            }
		                            else {
		                                line2 = line2 + line.charAt(x);
		                            }
		                      
				                }
				                
	                        }
			            }
			            //System.out.println("Comment is: " + line3);
			            bufferedReader.close();         
			  }  
			  catch(IOException ex) {
			      ex.printStackTrace();                 
			  }
		  }
		  
		  return(newAL);
	}//end of method


	 public static ArrayList<Event> InsertionSort(ArrayList<Event> input){
         
	        Event temp;
	        for (int i = 1; i < input.size(); i++) {
	            for(int j = i ; j > 0 ; j--){
	            	//getDate(input.get(j).dtstart);
	                if( getDate(input.get(j).dtstart) < getDate(input.get(j-1).dtstart) ){
	                    temp = input.get(j);
	                    input.set(j, input.get(j-1));
	                    input.set(j-1, temp);
	                }
	            }
	        }
	        return input;
	 }
	
	 public static int getDate(String datetime){
		 
		 int swt = 0;
		 String line = "";
		 //String line2 = "";
		 
		 for(int x = 0; x < datetime.length();x++) {

			 if(swt == 1) {
				 
				 if (datetime.charAt(x) != 'Z') {
					 line = line + datetime.charAt(x);
				 }
			 }
			 else if(datetime.charAt(x) == 'T') {
				 swt = 1;
			 }
		 }
		 int out = Integer.parseInt(line);
		 return(out);
	 }
	 
	 public static double[] getGeo(String geopos){
		 
		 double geo[] = new double[2]; //position 0 is the latitude, 1 is longitude
		 String lat = "";
		 String lon = "";
		 int swt = 0;
		 
		 for(int x = 0; x < geopos.length();x++) {

			 if (geopos.charAt(x) == ';') {
				 swt = 1;
			 }
		     else if(swt == 1) {
		    	  lat = lat + geopos.charAt(x);
			 }
			 else {
				 lon = lon + geopos.charAt(x);
			 }
		 }
		 //int out = Integer.parseInt(line);
		 //System.out.println(lat);
		 //System.out.println(lon);
		 
		 geo[0] = Double.parseDouble(lat);
		 geo[1] = Double.parseDouble(lon);
		 return(geo);
	 }
	 
		public static double GreatCircleDistance(double lat1, double lon1, double lat2, double lon2) {
				// same position
				if(lat1 == lat2 && lon1 == lon2) {
					return 0;
				}
				/* Earth Mean Radius */
				//final double earthRmile = 3953.0;
				final double earthRKm = 6371;
				double lat1R = Math.toRadians(lat1);
				double lat2R = Math.toRadians(lat2);
				double dLat = Math.toRadians(lat2 - lat1);
				double dLon = Math.toRadians(lon2 - lon1);
				double a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(lat1R) * Math.cos(lat2R) * Math.sin(dLon/2) * Math.sin(dLon/2);
				double c = 2 * Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
				double dist = earthRKm * c;
				return dist;
		}

		 public static ArrayList<Event> getGCD(ArrayList<Event> input){
			    //first position is the latitude, second position is the longitude
	         	double latlong1[] = new double[2];
	         	double latlong2[] = new double[2];
	         	double gcd = 0;
			 
		        for (int i = 0; i < (input.size() - 1); i++) {
		        	latlong1 = getGeo(input.get(i).geo);
		        	latlong1 = getGeo(input.get(i + 1).geo);
		        	gcd = GreatCircleDistance(latlong1[0], latlong1[1], latlong2[0], latlong2[1]);
		        	
		        	input.get(i).comment = "Great Circle Distance=" + gcd + "km/" + (gcd * 0.621371) + "mi" ;
		        }
		        return input;
		 }
		
  public static void main(String[] args) { 
	  
	  Event derp = new Event();
	  derp.desc = "lol";
	  int run = 1;
	  Scanner scan = new Scanner(System.in); 
	  String input = "";
	  ArrayList<String> inList = new ArrayList<String>();
	  //ArrayList<Event> eventAL = new ArrayList<Event>();
	  
	  
	  while(run == 1) {
		  
		  System.out.println("Enter a filename: ");
		  input = scan.nextLine();
		  
		  if (input.equals("exit") ) {
			  run = 0;
		  }
		  else {
			  inList.add(input);
		  }
	  }
	  
	  
	  //inList.add("test.ics");
	  //inList.add("test2.ics");
	  
	  ArrayList<Event> eventAL = getInput(inList);
	  eventAL = InsertionSort(eventAL);
	  
	  eventAL = getGCD(eventAL);
	  
	  for(int x = 0; x < eventAL.size();x++) {
		  System.out.println();
		  System.out.println("Event " + (x + 1));
		  System.out.println("start time is: " + eventAL.get(x).dtstart);
		  System.out.println("end time is: " + eventAL.get(x).dtend);
		  System.out.println("desc is: " + eventAL.get(x).desc);
		  System.out.println("location is: " + eventAL.get(x).location);
		  System.out.println("Summary is: " + eventAL.get(x).summary);
		  System.out.println("comment is: " + eventAL.get(x).comment);
		  System.out.println("geopos is: " + eventAL.get(x).geo);
	  }

	  System.out.println("Enter a filename for output: ");
	  input = scan.nextLine();
	  Jog.setLogger(new FileLogger(input));
	  
	    Jog.enableLevel(Level.BEGIN);
	    Jog.enableLevel(Level.CALSCALE);
	    Jog.enableLevel(Level.PRODID);
	    Jog.enableLevel(Level.DESCRIPTION);
	    Jog.enableLevel(Level.VERSION);
	    Jog.enableLevel(Level.DESCRIPTION);
	    Jog.enableLevel(Level.END);
	    Jog.enableLevel(Level.DTSTART);
	    Jog.enableLevel(Level.DTEND);
	    Jog.enableLevel(Level.LOCATION);
	    Jog.enableLevel(Level.COMMENT);
	    Jog.enableLevel(Level.SUMMARY);
	    Jog.enableLevel(Level.GEO);
	  
	    
	    Jog.begin("VCALENDAR");
	    Jog.prodid("-//Kerwin Yadao//ics314 1.0//EN");
	    Jog.version("2.0");
	    Jog.calscale("GREGORIAN");
	    
	  for(int x = 0; x < eventAL.size();x++) {
		  
		  
		    Jog.begin("VEVENT");
		    Jog.dtstart(eventAL.get(x).dtstart);
		    Jog.dtend(eventAL.get(x).dtend);
		    Jog.description(eventAL.get(x).desc);
		    Jog.location(eventAL.get(x).location);
		    Jog.summary(eventAL.get(x).summary);
		    Jog.comment(eventAL.get(x).comment);
		    Jog.geo(eventAL.get(x).geo);
		    Jog.end("VEVENT");		  
	  }
	    Jog.end("VCALENDAR");
	  
	  
	  //eventAL = getGCD(eventAL);
  }





}