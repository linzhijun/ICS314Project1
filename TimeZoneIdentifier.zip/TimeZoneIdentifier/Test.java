import java.util.Calendar;
import java.util.Scanner;
import java.util.TimeZone;


/**
 *Authors: Team Tres
 *First Team Deliverable
 *Demo for iCalendar;
 *February 25, 2016
 */
public class Test {
  public static void main(String[] args) {    

	    Jog.setLogger(new FileLogger("blue.ics"));
	    
	    Scanner inText = new Scanner(System.in);
	    
	    String k;
	    String b;
	    String s;
	    String v;
	    String q;
	    String y;
	    String f;
	    
	    Jog.enableLevel(Level.BEGIN);
	    Jog.enableLevel(Level.CALSCALE);
	    Jog.enableLevel(Level.PRODID);
	    Jog.enableLevel(Level.DESCRIPTION);
	    Jog.enableLevel(Level.VERSION);
	    Jog.enableLevel(Level.DESCRIPTION);
	    Jog.enableLevel(Level.END);
	    Jog.enableLevel(Level.DTSTART);
	    Jog.enableLevel(Level.DTEND);
	    Jog.enableLevel(Level.LOCATION);
	    Jog.enableLevel(Level.SUMMARY);
	    Jog.enableLevel(Level.GEO);
	    Jog.enableLevel(Level.TZID);
	    /*
	    Calendar cal = Calendar.getInstance();
	    long milliDiff = cal.get(Calendar.ZONE_OFFSET);
	    // Got local offset, now loop through available timezone id(s).
	    String [] ids = TimeZone.getAvailableIDs();
	    String name = null;
	    for (String id : ids) {
	      TimeZone tz = TimeZone.getTimeZone(id);
	      if (tz.getRawOffset() == milliDiff) {
	        // Found a match.
	        name = id;
	        break;
	      }
	    }
	    
	    System.out.println(name);
		*/
	    
	    Calendar now = Calendar.getInstance();
	    
	    //get current TimeZone using getTimeZone method of Calendar class
	    TimeZone timeZone = now.getTimeZone();
	    
	    String u = timeZone.getDisplayName();
	    
	    System.out.println("Please enter location: ");
	    k = inText.nextLine();
	    
	    System.out.println("Please enter summary: ");
	    b = inText.nextLine();
	    
	    System.out.println("Please enter description: ");
	    s = inText.nextLine();
	    
	    System.out.println("Please enter geographical position (format: "
	    		+ "37.386013;"
	    		+ "-122.082932): ");
	    v = inText.nextLine();
	    
	    System.out.println("Please enter start time (format: 20160225T153000Z): ");
	    q = inText.nextLine();
	    
	    System.out.println("Please enter end time (format: 20160225T163000Z): ");
	    y = inText.nextLine();
	    
	    /*
	    Jog.begin("VCALENDAR");
	    Jog.prodid("-//Kerwin Yadao//ics314 1.0//EN");
	    Jog.version("2.0");
	    Jog.calscale("GREGORIAN");
	    Jog.begin("VEVENT");
	    Jog.dtstart("20160225T153000Z");
	    Jog.dtend("20160225T163000Z");
	    Jog.description("super desc");
	    Jog.location(k);
	    Jog.summary("asdf");
	    Jog.end("VEVENT");
	    Jog.geo("37.386013;-122.082932");
	    Jog.end("VCALENDAR");
	    */
	    
	    Jog.begin("VCALENDAR");
	    Jog.prodid("-//Kerwin Yadao//ics314 1.0//EN");
	    Jog.version("2.0");
	    Jog.calscale("GREGORIAN");
	    Jog.begin("VEVENT");
	    Jog.tzid(u);
	    Jog.dtstart(q);
	    Jog.dtend(y);
	    Jog.description(s);
	    Jog.location(k);
	    Jog.summary(b);
	    Jog.geo(v);
	    Jog.end("VEVENT");
	    Jog.end("VCALENDAR");
	    
	    Jog.printLog();
	    
  }

}
